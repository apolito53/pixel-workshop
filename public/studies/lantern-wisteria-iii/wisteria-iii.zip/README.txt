LANTERN WISTERIA III
Coastal wind study · Pixel Workshop

Open index.html to play, slow down or scrub the gust. In the isolated tree view, open Tree layers to hide individual flower sprays, boughs, or the lantern.

Open wisteria-iii.pixel.json in Pixel Workshop to edit the 20-layer tree on its 256 × 224 transparent canvas. Open wisteria-iii-coast.pixel.json for the same layers on the 384 × 248 coast, with separate shore, wavelets and root shadow.

The animation runs at 12 fps for 42 frames (3.5 seconds). Each PNG sprite sheet has seven columns and six rows. Its matching JSON atlas lists the frame rectangles and playback order. Use nearest-neighbor filtering to preserve the pixel edges.

layer-poses.png and layers.js contain the separate cropped poses and their anchor positions for the tree layer viewer. still.png is the full composited scene at its poster frame.

https://pixel-workshop-nine.vercel.app/studies/lantern-wisteria-iii/
