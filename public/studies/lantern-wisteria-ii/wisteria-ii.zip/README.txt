LANTERN WISTERIA II
Pixel Workshop · Coastal wind study

Open index.html to watch the loop, scrub frames, or isolate tufts under Tree > Tree layers. The player also runs from an extracted local folder.

EDITABLE PROJECTS
Use Open project in Pixel Workshop with wisteria-ii.pixel.json for the fully separated tree. Its 20 layers include eight leaf tufts, nine groups of hanging blossoms, the root flare, the trunk with branches, and the suspended lantern.
wisteria-ii-coast.pixel.json keeps those same 20 tree layers on the 384 × 248 coastal canvas, plus three independent layers for the shore, reflected wavelets, and root contact shadow.

GAME ASSETS
tree-sheet.png / tree-atlas.json — 256 × 224 transparent tree frames.
scene-sheet.png / scene-atlas.json — 384 × 248 complete coast frames.
Both sheets use six columns and four rows. Play the named Sea breeze clip at 8 fps for a seamless three-second loop. The PNGs retain the exact working pixels. Use nearest-neighbor filtering.
layer-poses.png / layers.js — tightly trimmed transparent layer poses and their per-frame order, offsets and atlas coordinates, shared with the player.
still.png is the full-scene poster.

https://pixel-workshop-nine.vercel.app/studies/lantern-wisteria-ii/index.html
