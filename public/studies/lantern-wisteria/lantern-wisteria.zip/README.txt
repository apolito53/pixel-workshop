Lantern Wisteria
================

A coastal wind study made for Pixel Workshop. A gust crosses the wisteria
from left to right and the brass lantern catches up. The animation returns
to rest before the next gust.

Open index.html after extracting the folder to watch the coast or the
isolated sprite. Pause, step or scrub to inspect individual poses.

Open lantern-wisteria.pixel.json in Pixel Workshop for the editable tree.
It has three layers, 18 frames at 6 fps, and a looping Wind clip. Its
128 x 128 frame has a ground contact point at (47,119), measured from the
top-left corner with zero-based pixel coordinates.

Open lantern-coast.pixel.json in the expanded Workshop for the whole
320 x 180 scene. It has four editable layers across 18 frames. The tree's
top-left corner in the scene is (48,33). Both projects have a three-second
loop. The scene uses the compact project encoding added with this study.

For your game, lantern-wisteria-sheet.png is a transparent RGBA sprite
sheet. Slice 128 x 128 frames in six columns and three rows, or use
lantern-wisteria-atlas.json. Frame order is left to right, then down.
Use nearest-neighbor sampling. coast-sheet.png is the 320 x 180-per-frame
flattened scene preview, also in six columns and three rows.
